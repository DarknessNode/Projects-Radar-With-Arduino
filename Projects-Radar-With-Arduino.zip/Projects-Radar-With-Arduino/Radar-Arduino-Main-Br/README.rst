

###################
Criando um Radar Arduíno com monitoramento pelo PC
###################

Neste vídeo vamos criar u protótipo de um Radar que ficará rastreando se objetos estão chegando próximos a ele e o resultado da sua varredura será mostrada em tela no Computador.

*******************
Link com instruções em vídeo: https://youtu.be/xLisFiPiG5g
*******************

Lista de Dispositivos:

- 1 Arduíno Uno;
- 1 Protoboard;
- 4 Jumpers Macho/Fêmea;
- 7 Jumpers Macho/Macho;
- 1 Sensor de Ultrassom HC-SR04;
- 1 Micro Servo Motor de 9g;
- Alguns elásticos e um pedaço de papel para criação da base.

Link para download do Processing: http://bit.ly/2K2JKx3

Todos os dispositivos usados neste vídeo você encontra no Kit de Arduino Iniciante V8 da Robocore neste Link: http://bit.ly/2UfXYvK




